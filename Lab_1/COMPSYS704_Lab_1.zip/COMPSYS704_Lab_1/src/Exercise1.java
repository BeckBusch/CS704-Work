// Each java file must have one public class with the same name
public class Exercise1 {
	// The main function is the entry point for execution
	public static void main(String[] args) {
		int x = 20;
		int y = 22;

		// TODO: Replace the ellipses
		System.out.println(...);
		System.out.println(... + "!");
		System.out.println("The year is: " + ...);
		System.out.println("The result is: " + ...);
		System.out.println("The result is: " + ...);
	}
}
