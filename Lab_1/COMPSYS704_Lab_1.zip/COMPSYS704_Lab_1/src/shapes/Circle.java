package shapes;

public class Circle extends Shape {
	// TODO: Implement as per the UML
}
