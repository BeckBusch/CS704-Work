package shapes;

public class Square extends Shape {
	// TODO: Implement as per the UML
}
