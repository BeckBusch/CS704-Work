package shapes;

public abstract class Shape {
	// TODO: Implement as per the UML
}
